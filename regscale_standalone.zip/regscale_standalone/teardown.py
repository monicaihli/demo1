import os
import subprocess
import importlib.resources

pkg_path = str(importlib.resources.files('regscale_standalone'))
ATLAS_FILE = pkg_path + '/atlas.env'
DB_FILE = pkg_path + '/db.env'
DOCKER_COMPOSE_FILE = pkg_path + '/docker-compose.yml'
REGSCALE_LOCAL = "http://localhost:81"

def teardown():
    docker_command = 'docker-compose'
    #Determine if using docker compose v1 or v2
    try:
        subprocess.check_output('docker compose version', shell=True)
        print('Confirmed docker compose v2 command is available.')
        docker_command = 'docker compose'
    except:
        print('Current docker compose version is not v2. Proceeding with v1.')


    os.system(docker_command + " down")
    os.system("docker volume rm installers_atlasvolume")
    os.system("docker volume rm installers_sqlvolume")
    os.remove(ATLAS_FILE)
    os.remove(DB_FILE)
    os.remove("docker-compose.yml")