import os
import subprocess

 # need to add logic to confirm files exist before trying to remove

def teardown():
    docker_command = 'docker-compose'
    #Determine if using docker compose v1 or v2
    try:
        subprocess.check_output('docker compose version', shell=True)
        print('Confirmed docker compose v2 command is available.')
        docker_command = 'docker compose'
    except:
        print('Current docker compose version is not v2. Proceeding with v1.')

    os.system(docker_command + " down")
    os.system("docker volume rm installers_atlasvolume")
    os.system("docker volume rm installers_sqlvolume")
    os.remove("standalone/atlas.env")
    os.remove("db.env")
    os.remove("docker-compose.yml")